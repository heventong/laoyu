!function() {
    var p, q, r, a = function() {
        var b, c, d, e, a = document.getElementsByTagName("script");
        for (b = 0,
        c = a.length; c > b; b++)
            if (e = a[b],
            e.src && (d = /^(https?:)\/\/[\w\.\-]+\.cnzz\.com\//i.exec(e.src)))
                return d[1];
        return window.location.protocol
    }(), b = encodeURIComponent, c = "1275384701", d = "", e = "", f = "online_v3.php", g = "z5.cnzz.com", h = "1", i = "text", j = "z", k = "&#31449;&#38271;&#32479;&#35745;", l = window["_CNZZDbridge_" + c]["bobject"], m = "0", n = a + "//online.cnzz.com/online/" + f, o = [];
    o.push("id=" + c),
    o.push("h=" + g),
    o.push("on=" + b(e)),
    o.push("s=" + b(d)),
    n += "?" + o.join("&"),
    "0" === m && l["callRequest"]([a + "//cnzz.mmstat.com/9.gif?abc=1"]),
    h && ("" !== e ? l["createScriptIcon"](n, "utf-8") : (q = "z" == j ? "https://www.cnzz.com/stat/website.php?web_id=" + c : "https://quanjing.cnzz.com",
    "pic" === i ? (r = a + "//icon.cnzz.com/img/" + d + ".gif",
    p = "<a href='" + q + "' target=_blank title='" + k + "'><img border=0 hspace=0 vspace=0 src='" + r + "'></a>") : p = "<a href='" + q + "' target=_blank title='" + k + "'>" + k + "</a>",
    l["createIcon"]([p])))
}();
